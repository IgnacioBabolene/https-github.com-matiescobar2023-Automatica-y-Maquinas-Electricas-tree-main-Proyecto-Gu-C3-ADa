// Ejercicio 2 TP2

/*Cree 2 funciones en C:
1. Una función para pasar de punto fijo a punto flotante, fx2fp( ).
2. Una función para pasar de punto flotante a punto fijo, fp2fx( ).
3. Verifique el correcto funcionamiento haciendo,
b = fx2fp( fp2fx( 2.4515) )
4. Compare b con 2.4515 para Q23.8 y Q21.10.
*/

#include <stdio.h>
#include <stdbool.h>


void fx2fp(int num_entero,unsigned short opcion){  //Punto fijo a flotante
    float num_flotante = (float)num_entero / (1 << 3);
    printf("El número entero %d convertido a flotante es: %.5f\n", num_entero, num_flotante);
    if (opcion == 3){
        printf("El número entero %d convertido a flotante para Q23.8 es: %23.8f\n", num_entero, num_flotante);
        printf("El número entero %d convertido a flotante para Q23.8 es: %21.10f\n", num_entero, num_flotante);
    }
}

void fp2fx(float num_flotante, unsigned short opcion){  //Punto flotante a fijo
    float num_entero = (int)(num_flotante *(1 << 3));
    printf("El número flotante %.2f convertido a entero es: %d\n", num_flotante, num_entero);
    if (opcion == 3){
        fx2fp(num_entero,opcion);
    }
}

int main(){

    unsigned short opcion;
    printf("Desea convertir un numero entero en flotante (0) o viceversa (1)?");
    scanf("%hd", &opcion);

    if (opcion == 0){
        int numero;
        printf("Ingrese valor de punto fijo a convertir");
        scanf("%d", &numero);
        fx2fp(numero,opcion);
    }
    else if(opcion == 1){
        float numero;
        printf("Ingrese el valor de punto flotante a convertir");
        scanf("%f", &numero);
        fp2fx(numero,opcion);
    }
    else{
        float valor_prueba = 2.4515;
        fp2fx(valor_prueba,opcion);
    }
}