//Ejercicio 4

/*Implemente la suma de dos números con aritmética de saturación,
int32_t saturation(int32_t a, int32_t b)
1. Utilice las constantes INT_MAX e INT_MIN definidas en la biblioteca limits.h para la
2. Opere con una serie de número para verificar que saturation() funciona correctamente.*/

#include <stdint.h>

int32_t saturate(int32_t a, int32_t b){
    if(a+b > INT32_MAX){
        return INT32_MAX;
    }
    else if((a+b) < INT32_MIN){
        return INT32_MIN;
    }
    else{
        return (int32_t)(a+b);
    }
}

void main(){
    int32_t a,b;
    printf("Ingrese el valor de a: ");
    scanf("%d", &a);
    printf("Ingrese el valor de b: ");
    scanf("%d", &b);
    int32_t resultado_saturado = saturate(a,b);
    printf("El resultado saturado de %d + %d es = %d",a,b,resultado_saturado);
}