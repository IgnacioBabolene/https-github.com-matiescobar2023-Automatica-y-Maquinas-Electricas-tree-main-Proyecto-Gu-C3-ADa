//Ejercicio 3

/*Multiplique dos números en Q21.10. El resultado debe ser ajustado según los dos esquemas de
redondeos estudiados.
1. Cree una función que implemente redondeo por truncación.
int32_t truncation(int64_t X)
2. Cree una función que implemente redondeo al valor más cercano.
int32_t rounding(int64_t X)
1
3. Compare el resultado de cada esquema de redondeo con el resultado que obtendría usando
números en formato double.*/

#include <stdint.h>
#include <stdio.h>

int32_t truncation(int64_t x,int8_t n){
    int32_t num_truncado = (int32_t)(x<<n);
    return num_truncado;
}

int32_t  rounding(int64_t x,int8_t n){
    int32_t num_aux = x + (1<<(n-1));
    return truncation(num_aux,n);
}

void main(){

    int64_t numero;
    printf("Ingrese numero: ");
    scanf("%d", &numero);

    int8_t n;
    printf("Ingrese cant de bits que quiere dejar de la parte fraccionaria: ");
    scanf("%d", &n);

    int32_t num_truncado = truncation(numero,n);
    int32_t num_redondeado = rounding(numero,n);

    printf("Numero truncado = %d\n", num_truncado);
    printf("Numero redondeado = %d\n", num_redondeado);
}