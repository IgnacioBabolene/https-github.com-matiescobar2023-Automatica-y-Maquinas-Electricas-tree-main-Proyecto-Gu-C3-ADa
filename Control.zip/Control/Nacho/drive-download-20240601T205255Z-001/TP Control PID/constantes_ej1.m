close all; clear all; clc;

b = 200;
a = 10000;
m = 1500;
g = 9.82;
