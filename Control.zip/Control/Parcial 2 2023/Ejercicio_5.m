%% Ejercicio 5: Desconecte el PI del sensor de velocidad y
%% cierre el lazo de control con la velocidad estimada 
%% por el observador.
% La velocidad real del sistema controlado por el PI,
% alimentado con la velocidad estimada por el observador,
% deber�a ser menos ruidosa que cuando se utilizaba el 
% sensor de velocidad

%% Entrega: PARCIAL_2_Apellido_E5.slx
