%% Ejercicio 1: El archivo de simulink contiene el modelo
% de un veh�culo que aterriza verticalmente usando un
% motor propulsor.
% El objetivo de control es descender a una velocidad 
% constante de -50 m/s.
% El controlador ya fue dise�ado con un PI y est� funcionando 
% correctamente.
% Problema: la acci�n de control en valor absoluto supera 
% 10^5 N, que es la m�xima fuerza que puede hacer el motor.

%% Tarea: Modifique la estructura del controlador PI
% de manera tal que la din�mica a lazo cerrado frente a las 
% perturbaciones permanezca igual, pero que la din�mica 
% frente a los escalones de la referencia se suavice.
% Luego de la modificaci�n, la acci�n de control no 
% deber�a superar los 9 * 10^4 N.

%% Entrega: PARCIAL_2_Apellido_E1.slx


