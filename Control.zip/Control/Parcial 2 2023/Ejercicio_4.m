%% Ejercicio 4: Implemente el observador en 
% el archivo de simulink y verifique si puede estimar
% la velocidad a partir del sensor de posici�n.

%% Entrega: PARCIAL_2_Apellido_E4.slx
