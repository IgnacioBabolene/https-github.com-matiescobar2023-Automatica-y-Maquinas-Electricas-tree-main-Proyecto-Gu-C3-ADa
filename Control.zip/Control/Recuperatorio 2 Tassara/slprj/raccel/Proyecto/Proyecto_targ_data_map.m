    function targMap = targDataMap(),

    ;%***********************
    ;% Create Parameter Map *
    ;%***********************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 1;
        sectIdxOffset = 0;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc paramMap
        ;%
        paramMap.nSections           = nTotSects;
        paramMap.sectIdxOffset       = sectIdxOffset;
            paramMap.sections(nTotSects) = dumSection; %prealloc
        paramMap.nTotData            = -1;

        ;%
        ;% Auto data (rtP)
        ;%
            section.nData     = 13;
            section.data(13)  = dumData; %prealloc

                    ;% rtP.Q
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.area_mem
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 1;

                    ;% rtP.f
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 2;

                    ;% rtP.k
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 8194;

                    ;% rtP.m
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 8195;

                    ;% rtP.perm
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 8196;

                    ;% rtP.r1
                    section.data(7).logicalSrcIdx = 6;
                    section.data(7).dtTransOffset = 8197;

                    ;% rtP.rho
                    section.data(8).logicalSrcIdx = 7;
                    section.data(8).dtTransOffset = 8198;

                    ;% rtP.v_sonido
                    section.data(9).logicalSrcIdx = 8;
                    section.data(9).dtTransOffset = 8199;

                    ;% rtP.vol
                    section.data(10).logicalSrcIdx = 9;
                    section.data(10).dtTransOffset = 8200;

                    ;% rtP.AudioDeviceWriter_P1
                    section.data(11).logicalSrcIdx = 10;
                    section.data(11).dtTransOffset = 8201;

                    ;% rtP.Integrator1_IC
                    section.data(12).logicalSrcIdx = 11;
                    section.data(12).dtTransOffset = 8202;

                    ;% rtP.Integrator_IC
                    section.data(13).logicalSrcIdx = 12;
                    section.data(13).dtTransOffset = 8203;

            nTotData = nTotData + section.nData;
            paramMap.sections(1) = section;
            clear section


            ;%
            ;% Non-auto Data (parameter)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        paramMap.nTotData = nTotData;



    ;%**************************
    ;% Create Block Output Map *
    ;%**************************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 2;
        sectIdxOffset = 0;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc sigMap
        ;%
        sigMap.nSections           = nTotSects;
        sigMap.sectIdxOffset       = sectIdxOffset;
            sigMap.sections(nTotSects) = dumSection; %prealloc
        sigMap.nTotData            = -1;

        ;%
        ;% Auto data (rtB)
        ;%
            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.i3u03phd0f
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(1) = section;
            clear section

            section.nData     = 13;
            section.data(13)  = dumData; %prealloc

                    ;% rtB.ecfj3j5uro
                    section.data(1).logicalSrcIdx = 1;
                    section.data(1).dtTransOffset = 0;

                    ;% rtB.bdmnxfqidc
                    section.data(2).logicalSrcIdx = 2;
                    section.data(2).dtTransOffset = 4096;

                    ;% rtB.pb04l5mcnn
                    section.data(3).logicalSrcIdx = 3;
                    section.data(3).dtTransOffset = 12288;

                    ;% rtB.gwjjbx0bgf
                    section.data(4).logicalSrcIdx = 4;
                    section.data(4).dtTransOffset = 16384;

                    ;% rtB.jfc40fz1ad
                    section.data(5).logicalSrcIdx = 5;
                    section.data(5).dtTransOffset = 20480;

                    ;% rtB.gntxv1dbio
                    section.data(6).logicalSrcIdx = 6;
                    section.data(6).dtTransOffset = 20481;

                    ;% rtB.el3jpggm4r
                    section.data(7).logicalSrcIdx = 7;
                    section.data(7).dtTransOffset = 20482;

                    ;% rtB.p5bw4t5tn5
                    section.data(8).logicalSrcIdx = 8;
                    section.data(8).dtTransOffset = 20483;

                    ;% rtB.nok05lpty1
                    section.data(9).logicalSrcIdx = 9;
                    section.data(9).dtTransOffset = 20484;

                    ;% rtB.eklbxs4vpm
                    section.data(10).logicalSrcIdx = 10;
                    section.data(10).dtTransOffset = 20485;

                    ;% rtB.mv32qtj0sl
                    section.data(11).logicalSrcIdx = 11;
                    section.data(11).dtTransOffset = 20486;

                    ;% rtB.kgnmu0nbpd
                    section.data(12).logicalSrcIdx = 12;
                    section.data(12).dtTransOffset = 20487;

                    ;% rtB.n3x22j4bj5
                    section.data(13).logicalSrcIdx = 13;
                    section.data(13).dtTransOffset = 24583;

            nTotData = nTotData + section.nData;
            sigMap.sections(2) = section;
            clear section


            ;%
            ;% Non-auto Data (signal)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        sigMap.nTotData = nTotData;



    ;%*******************
    ;% Create DWork Map *
    ;%*******************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 4;
        sectIdxOffset = 2;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc dworkMap
        ;%
        dworkMap.nSections           = nTotSects;
        dworkMap.sectIdxOffset       = sectIdxOffset;
            dworkMap.sections(nTotSects) = dumSection; %prealloc
        dworkMap.nTotData            = -1;

        ;%
        ;% Auto data (rtDW)
        ;%
            section.nData     = 6;
            section.data(6)  = dumData; %prealloc

                    ;% rtDW.deenoxubya
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.gwuhcdxzlc
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 137;

                    ;% rtDW.ld1nu1dxpt
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 142;

                    ;% rtDW.ax05nlxr2w
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 153;

                    ;% rtDW.o33j1gid55
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 290;

                    ;% rtDW.eouyxbaxdu
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 295;

            nTotData = nTotData + section.nData;
            dworkMap.sections(1) = section;
            clear section

            section.nData     = 5;
            section.data(5)  = dumData; %prealloc

                    ;% rtDW.nzzir3uxyc.LoggedData
                    section.data(1).logicalSrcIdx = 6;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.dbnaap3jtb.LoggedData
                    section.data(2).logicalSrcIdx = 7;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.i12kc3kval.LoggedData
                    section.data(3).logicalSrcIdx = 8;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.kkrfdobbzq.LoggedData
                    section.data(4).logicalSrcIdx = 9;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.mgynybnprj.LoggedData
                    section.data(5).logicalSrcIdx = 10;
                    section.data(5).dtTransOffset = 4;

            nTotData = nTotData + section.nData;
            dworkMap.sections(2) = section;
            clear section

            section.nData     = 2;
            section.data(2)  = dumData; %prealloc

                    ;% rtDW.hfrsrhmfpp
                    section.data(1).logicalSrcIdx = 11;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.ohocjpj4e2
                    section.data(2).logicalSrcIdx = 12;
                    section.data(2).dtTransOffset = 1;

            nTotData = nTotData + section.nData;
            dworkMap.sections(3) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.hydjt5fo3a
                    section.data(1).logicalSrcIdx = 13;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(4) = section;
            clear section


            ;%
            ;% Non-auto Data (dwork)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        dworkMap.nTotData = nTotData;



    ;%
    ;% Add individual maps to base struct.
    ;%

    targMap.paramMap  = paramMap;
    targMap.signalMap = sigMap;
    targMap.dworkMap  = dworkMap;

    ;%
    ;% Add checksums to base struct.
    ;%


    targMap.checksum0 = 4041121728;
    targMap.checksum1 = 1364811362;
    targMap.checksum2 = 3135683545;
    targMap.checksum3 = 867860109;

