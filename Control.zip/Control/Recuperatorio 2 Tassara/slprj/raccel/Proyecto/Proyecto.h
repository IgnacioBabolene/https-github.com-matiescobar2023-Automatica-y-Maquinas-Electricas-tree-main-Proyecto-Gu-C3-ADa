#ifndef RTW_HEADER_Proyecto_h_
#define RTW_HEADER_Proyecto_h_
#ifndef Proyecto_COMMON_INCLUDES_
#define Proyecto_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#include "HostLib_MMFile.h"
#include "HostLib_Multimedia.h"
#include "HostLib_Audio.h"
#endif
#include "Proyecto_types.h"
#include <stddef.h>
#include "rtw_modelmap_simtarget.h"
#include "rt_defines.h"
#include <string.h>
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#define MODEL_NAME Proyecto
#define NSAMPLE_TIMES (3) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (14) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (2)   
#elif NCSTATES != 2
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T i3u03phd0f [ 8192 ] ; creal_T malgcsryoz_mbvzarwird [
4096 ] ; real_T ecfj3j5uro [ 4096 ] ; real_T bdmnxfqidc [ 8192 ] ; real_T
pb04l5mcnn [ 4096 ] ; real_T gwjjbx0bgf [ 4096 ] ; real_T jfc40fz1ad ; real_T
gntxv1dbio ; real_T el3jpggm4r ; real_T p5bw4t5tn5 ; real_T nok05lpty1 ;
real_T eklbxs4vpm ; real_T mv32qtj0sl ; real_T kgnmu0nbpd [ 4096 ] ; real_T
n3x22j4bj5 [ 4096 ] ; real_T gembzqf1n5_cl54gopm0x [ 4096 ] ; real_T
apppmvqjqc_kkiq3xxxve [ 4096 ] ; } B ; typedef struct { real_T deenoxubya [
137 ] ; real_T gwuhcdxzlc [ 5 ] ; real_T ld1nu1dxpt [ 11 ] ; real_T
ax05nlxr2w [ 137 ] ; real_T o33j1gid55 [ 5 ] ; real_T eouyxbaxdu [ 11 ] ;
struct { void * LoggedData ; } nzzir3uxyc ; struct { void * LoggedData ; }
dbnaap3jtb ; struct { void * LoggedData ; } i12kc3kval ; struct { void *
LoggedData ; } kkrfdobbzq ; struct { void * LoggedData ; } mgynybnprj ;
int8_T hfrsrhmfpp ; int8_T ohocjpj4e2 ; uint8_T hydjt5fo3a [ 1096 ] ; } DW ;
typedef struct { real_T elr4yukyrp ; real_T azsqxuyxrn ; } X ; typedef struct
{ real_T elr4yukyrp ; real_T azsqxuyxrn ; } XDot ; typedef struct { boolean_T
elr4yukyrp ; boolean_T azsqxuyxrn ; } XDis ; typedef struct { real_T
elr4yukyrp ; real_T azsqxuyxrn ; } CStateAbsTol ; typedef struct { real_T
elr4yukyrp ; real_T azsqxuyxrn ; } CXPtMin ; typedef struct { real_T
elr4yukyrp ; real_T azsqxuyxrn ; } CXPtMax ; typedef struct { real_T
pkmaui34yo [ 3072 ] ; } ConstP ; typedef struct { rtwCAPI_ModelMappingInfo
mmi ; } DataMapInfo ; struct P_ { real_T Q ; real_T area_mem ; real_T f [
8192 ] ; real_T k ; real_T m ; real_T perm ; real_T r1 ; real_T rho ; real_T
v_sonido ; real_T vol ; real_T AudioDeviceWriter_P1 ; real_T Integrator1_IC ;
real_T Integrator_IC ; } ; extern const char_T * RT_MEMORY_ALLOCATION_ERROR ;
extern B rtB ; extern X rtX ; extern DW rtDW ; extern P rtP ; extern const
ConstP rtConstP ; extern mxArray * mr_Proyecto_GetDWork ( ) ; extern void
mr_Proyecto_SetDWork ( const mxArray * ssDW ) ; extern mxArray *
mr_Proyecto_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * Proyecto_GetCAPIStaticMap ( void ) ; extern
SimStruct * const rtS ; extern const int_T gblNumToFiles ; extern const int_T
gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ; extern rtInportTUtable
* gblInportTUtables ; extern const char * gblInportFileName ; extern const
int_T gblNumRootInportBlks ; extern const int_T gblNumModelInputs ; extern
const int_T gblInportDataTypeIdx [ ] ; extern const int_T gblInportDims [ ] ;
extern const int_T gblInportComplex [ ] ; extern const int_T
gblInportInterpoFlag [ ] ; extern const int_T gblInportContinuous [ ] ;
extern const int_T gblParameterTuningTid ; extern DataMapInfo *
rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr ;
void MdlOutputs ( int_T tid ) ; void MdlOutputsParameterSampleTime ( int_T
tid ) ; void MdlUpdate ( int_T tid ) ; void MdlTerminate ( void ) ; void
MdlInitializeSizes ( void ) ; void MdlInitializeSampleTimes ( void ) ;
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) ;
#endif
