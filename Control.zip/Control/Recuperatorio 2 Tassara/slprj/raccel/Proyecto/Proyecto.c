#include "Proyecto.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <string.h>
#include "Proyecto_private.h"
#include "mwmathutil.h"
#include "rt_logging_mmi.h"
#include "Proyecto_capi.h"
#include "Proyecto_dt.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 2 , & stopRequested ) ; }
rtExtModeShutdown ( 2 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 0 ; int_T gbl_raccel_NumST = 3 ; const char_T
* gbl_raccel_Version = "9.9 (R2023a) 19-Nov-2022" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 } ; const char * raccelLoadInputsAndAperiodicHitTimes (
SimStruct * S , const char * inportFileName , int * matFileFormat ) { return
rt_RAccelReadInportsMatFile ( S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
B rtB ; X rtX ; DW rtDW ; static SimStruct model_S ; SimStruct * const rtS =
& model_S ; void MWDSPCG_FFT_Interleave_R2BR_D ( const real_T x [ ] , creal_T
y [ ] , int32_T nChans , int32_T nRows ) { int32_T bit_fftLen ; int32_T br_j
; int32_T j ; int32_T nChansBy2 ; int32_T uIdx ; int32_T yIdx ; br_j = 0 ;
yIdx = 0 ; uIdx = 0 ; for ( nChansBy2 = nChans >> 1 ; nChansBy2 != 0 ;
nChansBy2 -- ) { for ( j = nRows ; j - 1 > 0 ; j -- ) { y [ yIdx + br_j ] .
re = x [ uIdx ] ; y [ yIdx + br_j ] . im = x [ uIdx + nRows ] ; uIdx ++ ;
bit_fftLen = nRows ; do { bit_fftLen = ( int32_T ) ( ( uint32_T ) bit_fftLen
>> 1 ) ; br_j ^= bit_fftLen ; } while ( ( br_j & bit_fftLen ) == 0 ) ; } y [
yIdx + br_j ] . re = x [ uIdx ] ; y [ yIdx + br_j ] . im = x [ uIdx + nRows ]
; uIdx = ( uIdx + nRows ) + 1 ; yIdx += nRows << 1 ; br_j = 0 ; } if ( ( (
uint32_T ) nChans & 1U ) != 0U ) { for ( j = nRows >> 1 ; j - 1 > 0 ; j -- )
{ y [ yIdx + br_j ] . re = x [ uIdx ] ; y [ yIdx + br_j ] . im = x [ uIdx + 1
] ; uIdx += 2 ; bit_fftLen = nRows >> 1 ; do { bit_fftLen = ( int32_T ) ( (
uint32_T ) bit_fftLen >> 1 ) ; br_j ^= bit_fftLen ; } while ( ( br_j &
bit_fftLen ) == 0 ) ; } y [ yIdx + br_j ] . re = x [ uIdx ] ; y [ yIdx + br_j
] . im = x [ uIdx + 1 ] ; } } void MWDSPCG_R2DIT_TBLS_Z ( creal_T y [ ] ,
int32_T nChans , int32_T nRows , int32_T fftLen , int32_T offset , const
real_T tablePtr [ ] , int32_T twiddleStep , boolean_T isInverse ) { real_T
tmp_im ; real_T tmp_re ; real_T twidIm ; real_T twidRe ; int32_T fwdInvFactor
; int32_T i1 ; int32_T i2 ; int32_T iCh ; int32_T idelta ; int32_T istart ;
int32_T ix ; int32_T j ; int32_T k ; int32_T kratio ; int32_T nHalf ; int32_T
nQtr ; int32_T offsetCh ; nHalf = ( fftLen >> 1 ) * twiddleStep ; nQtr =
nHalf >> 1 ; fwdInvFactor = isInverse ? - 1 : 1 ; offsetCh = offset ; for (
iCh = 0 ; iCh < nChans ; iCh ++ ) { for ( ix = offsetCh ; ix < ( fftLen +
offsetCh ) - 1 ; ix += 2 ) { tmp_re = y [ ix + 1 ] . re ; tmp_im = y [ ix + 1
] . im ; y [ ix + 1 ] . re = y [ ix ] . re - y [ ix + 1 ] . re ; y [ ix + 1 ]
. im = y [ ix ] . im - y [ ix + 1 ] . im ; y [ ix ] . re += tmp_re ; y [ ix ]
. im += tmp_im ; } idelta = 2 ; k = fftLen >> 2 ; kratio = k * twiddleStep ;
while ( k > 0 ) { i1 = offsetCh ; for ( ix = 0 ; ix < k ; ix ++ ) { i2 = i1 +
idelta ; tmp_re = y [ i2 ] . re ; tmp_im = y [ i2 ] . im ; y [ i2 ] . re = y
[ i1 ] . re - y [ i2 ] . re ; y [ i2 ] . im = y [ i1 ] . im - y [ i2 ] . im ;
y [ i1 ] . re += tmp_re ; y [ i1 ] . im += tmp_im ; i1 += idelta << 1 ; }
istart = offsetCh ; for ( j = kratio ; j < nHalf ; j += kratio ) { i1 =
istart + 1 ; twidRe = tablePtr [ j ] ; twidIm = tablePtr [ j + nQtr ] * (
real_T ) fwdInvFactor ; for ( ix = 0 ; ix < k ; ix ++ ) { i2 = i1 + idelta ;
tmp_re = y [ i2 ] . re * twidRe - y [ i2 ] . im * twidIm ; tmp_im = y [ i2 ]
. re * twidIm + y [ i2 ] . im * twidRe ; y [ i2 ] . re = y [ i1 ] . re -
tmp_re ; y [ i2 ] . im = y [ i1 ] . im - tmp_im ; y [ i1 ] . re += tmp_re ; y
[ i1 ] . im += tmp_im ; i1 += idelta << 1 ; } istart ++ ; } idelta <<= 1 ; k
>>= 1 ; kratio >>= 1 ; } offsetCh += nRows ; } } void MWDSPCG_FFT_DblLen_Z (
creal_T y [ ] , int32_T nChans , int32_T nRows , const real_T twiddleTable [
] , int32_T twiddleStep ) { real_T cTemp_im ; real_T cTemp_re ; real_T
tempOut0Im ; real_T tempOut0Re ; int32_T N2 ; int32_T N4 ; int32_T W4 ;
int32_T ix ; int32_T k ; int32_T yIdx ; N2 = nRows >> 1 ; N4 = N2 >> 1 ; W4 =
N4 * twiddleStep ; yIdx = ( nChans - 1 ) * nRows ; if ( nRows > 2 ) {
tempOut0Re = y [ N4 + yIdx ] . re ; tempOut0Im = y [ N4 + yIdx ] . im ; y [ (
N2 + N4 ) + yIdx ] . re = tempOut0Re ; y [ ( N2 + N4 ) + yIdx ] . im =
tempOut0Im ; y [ N4 + yIdx ] . re = tempOut0Re ; y [ N4 + yIdx ] . im = -
tempOut0Im ; } if ( nRows > 1 ) { y [ N2 + yIdx ] . re = y [ yIdx ] . re - y
[ yIdx ] . im ; y [ N2 + yIdx ] . im = 0.0 ; } y [ yIdx ] . re += y [ yIdx ]
. im ; y [ yIdx ] . im = 0.0 ; k = twiddleStep ; for ( ix = 1 ; ix < N4 ; ix
++ ) { tempOut0Re = ( y [ ( N2 - ix ) + yIdx ] . re + y [ ix + yIdx ] . re )
/ 2.0 ; tempOut0Im = ( y [ ix + yIdx ] . im - y [ ( N2 - ix ) + yIdx ] . im )
/ 2.0 ; cTemp_re = y [ ( N2 - ix ) + yIdx ] . re ; cTemp_im = y [ ix + yIdx ]
. re ; y [ ix + yIdx ] . re = ( y [ ( N2 - ix ) + yIdx ] . im + y [ ix + yIdx
] . im ) / 2.0 ; y [ ix + yIdx ] . im = ( cTemp_re - cTemp_im ) / 2.0 ;
cTemp_re = y [ ix + yIdx ] . re * twiddleTable [ k ] - - twiddleTable [ W4 -
k ] * y [ ix + yIdx ] . im ; cTemp_im = y [ ix + yIdx ] . im * twiddleTable [
k ] + - twiddleTable [ W4 - k ] * y [ ix + yIdx ] . re ; y [ ix + yIdx ] . re
= tempOut0Re + cTemp_re ; y [ ix + yIdx ] . im = tempOut0Im + cTemp_im ; y [
( nRows - ix ) + yIdx ] . re = y [ ix + yIdx ] . re ; y [ ( nRows - ix ) +
yIdx ] . im = - y [ ix + yIdx ] . im ; y [ ( N2 + ix ) + yIdx ] . re =
tempOut0Re - cTemp_re ; y [ ( N2 + ix ) + yIdx ] . im = tempOut0Im - cTemp_im
; y [ ( N2 - ix ) + yIdx ] . re = y [ ( N2 + ix ) + yIdx ] . re ; y [ ( N2 -
ix ) + yIdx ] . im = - y [ ( N2 + ix ) + yIdx ] . im ; k += twiddleStep ; } }
void MdlInitialize ( void ) { LibReset ( & rtDW . deenoxubya [ 0U ] ) ;
LibReset ( & rtDW . ax05nlxr2w [ 0U ] ) ; rtX . elr4yukyrp = rtP .
Integrator1_IC ; rtX . azsqxuyxrn = rtP . Integrator_IC ; } void MdlStart (
void ) { char_T * sErr ; { bool externalInputIsInDatasetFormat = false ; void
* pISigstreamManager = rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} sErr = GetErrorBuffer ( & rtDW . deenoxubya [ 0U ] ) ; CreateHostLibrary (
"frommmfile.dll" , & rtDW . deenoxubya [ 0U ] ) ; createAudioInfo ( & rtDW .
gwuhcdxzlc [ 0U ] , 1U , 1U , 44100.0 , 32 , 2 , 4096 , 0 , GetNullPointer (
) ) ; createVideoInfo ( & rtDW . ld1nu1dxpt [ 0U ] , 0U , 0.0 , 0.0 , "" , 0
, 0 , 0 , 0 , 1U , 0 , 0 , GetNullPointer ( ) ) ; if ( * sErr == 0 ) {
LibCreate_FromMMFile ( & rtDW . deenoxubya [ 0U ] , NULL ,
 "C:\\Users\\tobip\\Documents\\Control\\Proyecto final\\Discurso Roger Federer.mp3"
, 1 ,
 "C:\\Program Files\\MATLAB\\R2023a\\toolbox\\shared\\multimedia\\bin\\win64\\audio\\audiofilemfreaderplugin.dll"
,
 "C:\\Program Files\\MATLAB\\R2023a\\toolbox\\shared\\multimedia\\bin\\win64\\audioslconverter"
, & rtDW . gwuhcdxzlc [ 0U ] , & rtDW . ld1nu1dxpt [ 0U ] , 0U , 1U , 1U , 0U
, 0U , 1U , 1.0 , 9.2233720368547758E+18 , 0U ) ; } if ( * sErr == 0 ) {
LibStart ( & rtDW . deenoxubya [ 0U ] ) ; } if ( * sErr != 0 ) {
DestroyHostLibrary ( & rtDW . deenoxubya [ 0U ] ) ; if ( * sErr != 0 ) {
ssSetErrorStatus ( rtS , sErr ) ; ssSetStopRequested ( rtS , 1 ) ; } } sErr =
GetErrorBuffer ( & rtDW . ax05nlxr2w [ 0U ] ) ; CreateHostLibrary (
"frommmfile.dll" , & rtDW . ax05nlxr2w [ 0U ] ) ; createAudioInfo ( & rtDW .
o33j1gid55 [ 0U ] , 1U , 1U , 44100.0 , 32 , 2 , 4096 , 0 , GetNullPointer (
) ) ; createVideoInfo ( & rtDW . eouyxbaxdu [ 0U ] , 0U , 0.0 , 0.0 , "" , 0
, 0 , 0 , 0 , 1U , 0 , 0 , GetNullPointer ( ) ) ; if ( * sErr == 0 ) {
LibCreate_FromMMFile ( & rtDW . ax05nlxr2w [ 0U ] , NULL ,
"C:\\Users\\tobip\\Documents\\Control\\Proyecto final\\Ruido ambiente.mp3" ,
1 ,
 "C:\\Program Files\\MATLAB\\R2023a\\toolbox\\shared\\multimedia\\bin\\win64\\audio\\audiofilemfreaderplugin.dll"
,
 "C:\\Program Files\\MATLAB\\R2023a\\toolbox\\shared\\multimedia\\bin\\win64\\audioslconverter"
, & rtDW . o33j1gid55 [ 0U ] , & rtDW . eouyxbaxdu [ 0U ] , 0U , 1U , 1U , 0U
, 0U , 1U , 1.0 , 9.2233720368547758E+18 , 0U ) ; } if ( * sErr == 0 ) {
LibStart ( & rtDW . ax05nlxr2w [ 0U ] ) ; } if ( * sErr != 0 ) {
DestroyHostLibrary ( & rtDW . ax05nlxr2w [ 0U ] ) ; if ( * sErr != 0 ) {
ssSetErrorStatus ( rtS , sErr ) ; ssSetStopRequested ( rtS , 1 ) ; } } sErr =
GetErrorBuffer ( & rtDW . hydjt5fo3a [ 0U ] ) ; CreateHostLibrary (
"hostlibaudio.dll" , & rtDW . hydjt5fo3a [ 0U ] ) ; if ( * sErr == 0 ) {
LibCreate_Audio ( & rtDW . hydjt5fo3a [ 0U ] , 0 , "Default" , 1 , 1 , 1 ,
44100.0 , 3 , 4096 , 40960 , 4096 , 0 , NULL ) ; } if ( * sErr != 0 ) {
DestroyHostLibrary ( & rtDW . hydjt5fo3a [ 0U ] ) ; if ( * sErr != 0 ) {
ssSetErrorStatus ( rtS , sErr ) ; ssSetStopRequested ( rtS , 1 ) ; } } rtDW .
hfrsrhmfpp = 0 ; rtDW . ohocjpj4e2 = 0 ; MdlInitialize ( ) ; } void
MdlOutputs ( int_T tid ) { creal_T * malgcsryoz_p ; real_T bsse21l2rd ;
real_T gembzqf1n5_p ; real_T tmp ; int32_T loop ; char_T * sErr ; void *
audio ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { sErr = GetErrorBuffer ( & rtDW
. deenoxubya [ 0U ] ) ; audio = ( void * ) & rtB . i3u03phd0f [ 0U ] ;
LibOutputs_FromMMFile ( & rtDW . deenoxubya [ 0U ] , GetNullPointer ( ) ,
audio , GetNullPointer ( ) , GetNullPointer ( ) , GetNullPointer ( ) ) ; if (
* sErr != 0 ) { ssSetErrorStatus ( rtS , sErr ) ; ssSetStopRequested ( rtS ,
1 ) ; } memcpy ( & rtB . ecfj3j5uro [ 0 ] , & rtB . i3u03phd0f [ 0 ] , sizeof
( real_T ) << 12U ) ; sErr = GetErrorBuffer ( & rtDW . ax05nlxr2w [ 0U ] ) ;
audio = ( void * ) & rtB . bdmnxfqidc [ 0U ] ; LibOutputs_FromMMFile ( & rtDW
. ax05nlxr2w [ 0U ] , GetNullPointer ( ) , audio , GetNullPointer ( ) ,
GetNullPointer ( ) , GetNullPointer ( ) ) ; if ( * sErr != 0 ) {
ssSetErrorStatus ( rtS , sErr ) ; ssSetStopRequested ( rtS , 1 ) ; } memcpy (
& rtB . pb04l5mcnn [ 0 ] , & rtB . bdmnxfqidc [ 0 ] , sizeof ( real_T ) <<
12U ) ; for ( loop = 0 ; loop < 4096 ; loop ++ ) { rtB . gwjjbx0bgf [ loop ]
= rtB . ecfj3j5uro [ loop ] + rtB . pb04l5mcnn [ loop ] ; } sErr =
GetErrorBuffer ( & rtDW . hydjt5fo3a [ 0U ] ) ; LibUpdate_Audio ( & rtDW .
hydjt5fo3a [ 0U ] , & rtB . gwjjbx0bgf [ 0U ] , 0 , 4096 , 0U ) ; if ( * sErr
!= 0 ) { ssSetErrorStatus ( rtS , sErr ) ; ssSetStopRequested ( rtS , 1 ) ; }
} rtB . jfc40fz1ad = rtX . elr4yukyrp ; rtB . gntxv1dbio = rtP . Q / ( rtP .
area_mem * rtP . perm / rtB . jfc40fz1ad ) ; if ( ssIsSampleHit ( rtS , 1 , 0
) ) { for ( loop = 0 ; loop < 4096 ; loop ++ ) { rtB . gembzqf1n5_cl54gopm0x
[ loop ] = rtP . vol * rtB . ecfj3j5uro [ loop ] ; }
MWDSPCG_FFT_Interleave_R2BR_D ( & rtB . gembzqf1n5_cl54gopm0x [ 0U ] , & rtB
. malgcsryoz_mbvzarwird [ 0U ] , 1 , 4096 ) ; MWDSPCG_R2DIT_TBLS_Z ( & rtB .
malgcsryoz_mbvzarwird [ 0U ] , 1 , 4096 , 2048 , 0 , & rtConstP . pkmaui34yo
[ 0U ] , 2 , false ) ; MWDSPCG_FFT_DblLen_Z ( & rtB . malgcsryoz_mbvzarwird [
0U ] , 1 , 4096 , & rtConstP . pkmaui34yo [ 0U ] , 1 ) ; for ( loop = 0 ;
loop < 4096 ; loop ++ ) { malgcsryoz_p = & rtB . malgcsryoz_mbvzarwird [ loop
] ; rtB . gembzqf1n5_cl54gopm0x [ loop ] = muDoubleScalarHypot ( malgcsryoz_p
-> re , malgcsryoz_p -> im ) ; } if ( ssIsMajorTimeStep ( rtS ) ) { if ( rtDW
. hfrsrhmfpp != 0 ) { ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( rtS ) ; rtDW .
hfrsrhmfpp = 0 ; } for ( loop = 0 ; loop < 4096 ; loop ++ ) { rtB .
apppmvqjqc_kkiq3xxxve [ loop ] = muDoubleScalarSqrt ( rtB .
gembzqf1n5_cl54gopm0x [ loop ] ) ; } } else { for ( loop = 0 ; loop < 4096 ;
loop ++ ) { gembzqf1n5_p = rtB . gembzqf1n5_cl54gopm0x [ loop ] ; if (
gembzqf1n5_p < 0.0 ) { rtB . apppmvqjqc_kkiq3xxxve [ loop ] = -
muDoubleScalarSqrt ( muDoubleScalarAbs ( gembzqf1n5_p ) ) ; rtDW . hfrsrhmfpp
= 1 ; } else { rtB . apppmvqjqc_kkiq3xxxve [ loop ] = muDoubleScalarSqrt (
gembzqf1n5_p ) ; } } } tmp = - 0.0 ; for ( loop = 0 ; loop < 4096 ; loop ++ )
{ tmp += rtB . apppmvqjqc_kkiq3xxxve [ loop ] * rtB . kgnmu0nbpd [ loop ] ;
rtB . apppmvqjqc_kkiq3xxxve [ loop ] = rtP . vol * rtB . pb04l5mcnn [ loop ]
; } rtB . el3jpggm4r = tmp ; bsse21l2rd = rtP . rho * rtP . v_sonido * rtP .
area_mem / 1.4142135623730951 * rtB . el3jpggm4r * ( 1.0 / rtP . r1 ) ;
MWDSPCG_FFT_Interleave_R2BR_D ( & rtB . apppmvqjqc_kkiq3xxxve [ 0U ] , & rtB
. malgcsryoz_mbvzarwird [ 0U ] , 1 , 4096 ) ; MWDSPCG_R2DIT_TBLS_Z ( & rtB .
malgcsryoz_mbvzarwird [ 0U ] , 1 , 4096 , 2048 , 0 , & rtConstP . pkmaui34yo
[ 0U ] , 2 , false ) ; MWDSPCG_FFT_DblLen_Z ( & rtB . malgcsryoz_mbvzarwird [
0U ] , 1 , 4096 , & rtConstP . pkmaui34yo [ 0U ] , 1 ) ; for ( loop = 0 ;
loop < 4096 ; loop ++ ) { malgcsryoz_p = & rtB . malgcsryoz_mbvzarwird [ loop
] ; rtB . apppmvqjqc_kkiq3xxxve [ loop ] = muDoubleScalarHypot ( malgcsryoz_p
-> re , malgcsryoz_p -> im ) ; } if ( ssIsMajorTimeStep ( rtS ) ) { if ( rtDW
. ohocjpj4e2 != 0 ) { ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( rtS ) ; rtDW .
ohocjpj4e2 = 0 ; } for ( loop = 0 ; loop < 4096 ; loop ++ ) { rtB .
gembzqf1n5_cl54gopm0x [ loop ] = muDoubleScalarSqrt ( rtB .
apppmvqjqc_kkiq3xxxve [ loop ] ) ; } } else { for ( loop = 0 ; loop < 4096 ;
loop ++ ) { gembzqf1n5_p = rtB . apppmvqjqc_kkiq3xxxve [ loop ] ; if (
gembzqf1n5_p < 0.0 ) { rtB . gembzqf1n5_cl54gopm0x [ loop ] = -
muDoubleScalarSqrt ( muDoubleScalarAbs ( gembzqf1n5_p ) ) ; rtDW . ohocjpj4e2
= 1 ; } else { rtB . gembzqf1n5_cl54gopm0x [ loop ] = muDoubleScalarSqrt (
gembzqf1n5_p ) ; } } } tmp = - 0.0 ; for ( loop = 0 ; loop < 4096 ; loop ++ )
{ gembzqf1n5_p = rtB . gembzqf1n5_cl54gopm0x [ loop ] * rtB . n3x22j4bj5 [
loop ] ; rtB . gembzqf1n5_cl54gopm0x [ loop ] = gembzqf1n5_p ; tmp +=
gembzqf1n5_p ; } rtB . p5bw4t5tn5 = tmp ; rtB . nok05lpty1 = rtP . rho * rtP
. v_sonido * rtP . area_mem / 1.4142135623730951 * rtB . p5bw4t5tn5 * ( 1.0 /
rtP . r1 ) + bsse21l2rd ; } rtB . eklbxs4vpm = ( rtB . nok05lpty1 - rtP . k *
rtB . jfc40fz1ad ) * ( 1.0 / rtP . m ) ; rtB . mv32qtj0sl = rtX . azsqxuyxrn
; UNUSED_PARAMETER ( tid ) ; } void MdlOutputsTID2 ( int_T tid ) { memcpy ( &
rtB . kgnmu0nbpd [ 0 ] , & rtP . f [ 0 ] , sizeof ( real_T ) << 12U ) ;
memcpy ( & rtB . n3x22j4bj5 [ 0 ] , & rtP . f [ 0 ] , sizeof ( real_T ) <<
12U ) ; UNUSED_PARAMETER ( tid ) ; } void MdlUpdate ( int_T tid ) {
UNUSED_PARAMETER ( tid ) ; } void MdlUpdateTID2 ( int_T tid ) {
UNUSED_PARAMETER ( tid ) ; } void MdlDerivatives ( void ) { XDot * _rtXdot ;
_rtXdot = ( ( XDot * ) ssGetdX ( rtS ) ) ; _rtXdot -> elr4yukyrp = rtB .
mv32qtj0sl ; _rtXdot -> azsqxuyxrn = rtB . eklbxs4vpm ; } void MdlProjection
( void ) { } void MdlTerminate ( void ) { char_T * sErr ; sErr =
GetErrorBuffer ( & rtDW . deenoxubya [ 0U ] ) ; LibTerminate ( & rtDW .
deenoxubya [ 0U ] ) ; if ( * sErr != 0 ) { ssSetErrorStatus ( rtS , sErr ) ;
ssSetStopRequested ( rtS , 1 ) ; } LibDestroy ( & rtDW . deenoxubya [ 0U ] ,
0 ) ; DestroyHostLibrary ( & rtDW . deenoxubya [ 0U ] ) ; sErr =
GetErrorBuffer ( & rtDW . ax05nlxr2w [ 0U ] ) ; LibTerminate ( & rtDW .
ax05nlxr2w [ 0U ] ) ; if ( * sErr != 0 ) { ssSetErrorStatus ( rtS , sErr ) ;
ssSetStopRequested ( rtS , 1 ) ; } LibDestroy ( & rtDW . ax05nlxr2w [ 0U ] ,
0 ) ; DestroyHostLibrary ( & rtDW . ax05nlxr2w [ 0U ] ) ; sErr =
GetErrorBuffer ( & rtDW . hydjt5fo3a [ 0U ] ) ; LibTerminate ( & rtDW .
hydjt5fo3a [ 0U ] ) ; if ( * sErr != 0 ) { ssSetErrorStatus ( rtS , sErr ) ;
ssSetStopRequested ( rtS , 1 ) ; } LibDestroy_Audio ( & rtDW . hydjt5fo3a [
0U ] , 1 , 1 ) ; DestroyHostLibrary ( & rtDW . hydjt5fo3a [ 0U ] ) ; } static
void mr_Proyecto_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j
, const void * srcData , size_t numBytes ) ; static void
mr_Proyecto_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_Proyecto_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_Proyecto_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_Proyecto_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_Proyecto_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( real_T ) bitVal ) ) ; } static uint_T
mr_Proyecto_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) ; static uint_T
mr_Proyecto_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_Proyecto_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_Proyecto_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_Proyecto_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_Proyecto_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_Proyecto_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_Proyecto_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
real_T ) fieldVal ) ) ; } static uint_T
mr_Proyecto_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static uint_T
mr_Proyecto_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) { const uint_T
fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber ( srcArray
, i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u ) ; }
mxArray * mr_Proyecto_GetDWork ( ) { static const char_T * ssDWFieldNames [ 3
] = { "rtB" , "rtDW" , "NULL_PrevZCX" , } ; mxArray * ssDW =
mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_Proyecto_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & ( rtB ) ,
sizeof ( rtB ) ) ; { static const char_T * rtdwDataFieldNames [ 8 ] = {
"rtDW.deenoxubya" , "rtDW.gwuhcdxzlc" , "rtDW.ld1nu1dxpt" , "rtDW.ax05nlxr2w"
, "rtDW.o33j1gid55" , "rtDW.eouyxbaxdu" , "rtDW.hfrsrhmfpp" ,
"rtDW.ohocjpj4e2" , } ; mxArray * rtdwData = mxCreateStructMatrix ( 1 , 1 , 8
, rtdwDataFieldNames ) ; mr_Proyecto_cacheDataAsMxArray ( rtdwData , 0 , 0 ,
( const void * ) & ( rtDW . deenoxubya ) , sizeof ( rtDW . deenoxubya ) ) ;
mr_Proyecto_cacheDataAsMxArray ( rtdwData , 0 , 1 , ( const void * ) & ( rtDW
. gwuhcdxzlc ) , sizeof ( rtDW . gwuhcdxzlc ) ) ;
mr_Proyecto_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const void * ) & ( rtDW
. ld1nu1dxpt ) , sizeof ( rtDW . ld1nu1dxpt ) ) ;
mr_Proyecto_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const void * ) & ( rtDW
. ax05nlxr2w ) , sizeof ( rtDW . ax05nlxr2w ) ) ;
mr_Proyecto_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const void * ) & ( rtDW
. o33j1gid55 ) , sizeof ( rtDW . o33j1gid55 ) ) ;
mr_Proyecto_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const void * ) & ( rtDW
. eouyxbaxdu ) , sizeof ( rtDW . eouyxbaxdu ) ) ;
mr_Proyecto_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const void * ) & ( rtDW
. hfrsrhmfpp ) , sizeof ( rtDW . hfrsrhmfpp ) ) ;
mr_Proyecto_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const void * ) & ( rtDW
. ohocjpj4e2 ) , sizeof ( rtDW . ohocjpj4e2 ) ) ; mxSetFieldByNumber ( ssDW ,
0 , 1 , rtdwData ) ; } return ssDW ; } void mr_Proyecto_SetDWork ( const
mxArray * ssDW ) { ( void ) ssDW ; mr_Proyecto_restoreDataFromMxArray ( (
void * ) & ( rtB ) , ssDW , 0 , 0 , sizeof ( rtB ) ) ; { const mxArray *
rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_Proyecto_restoreDataFromMxArray ( ( void * ) & ( rtDW . deenoxubya ) ,
rtdwData , 0 , 0 , sizeof ( rtDW . deenoxubya ) ) ;
mr_Proyecto_restoreDataFromMxArray ( ( void * ) & ( rtDW . gwuhcdxzlc ) ,
rtdwData , 0 , 1 , sizeof ( rtDW . gwuhcdxzlc ) ) ;
mr_Proyecto_restoreDataFromMxArray ( ( void * ) & ( rtDW . ld1nu1dxpt ) ,
rtdwData , 0 , 2 , sizeof ( rtDW . ld1nu1dxpt ) ) ;
mr_Proyecto_restoreDataFromMxArray ( ( void * ) & ( rtDW . ax05nlxr2w ) ,
rtdwData , 0 , 3 , sizeof ( rtDW . ax05nlxr2w ) ) ;
mr_Proyecto_restoreDataFromMxArray ( ( void * ) & ( rtDW . o33j1gid55 ) ,
rtdwData , 0 , 4 , sizeof ( rtDW . o33j1gid55 ) ) ;
mr_Proyecto_restoreDataFromMxArray ( ( void * ) & ( rtDW . eouyxbaxdu ) ,
rtdwData , 0 , 5 , sizeof ( rtDW . eouyxbaxdu ) ) ;
mr_Proyecto_restoreDataFromMxArray ( ( void * ) & ( rtDW . hfrsrhmfpp ) ,
rtdwData , 0 , 6 , sizeof ( rtDW . hfrsrhmfpp ) ) ;
mr_Proyecto_restoreDataFromMxArray ( ( void * ) & ( rtDW . ohocjpj4e2 ) ,
rtdwData , 0 , 7 , sizeof ( rtDW . ohocjpj4e2 ) ) ; } } mxArray *
mr_Proyecto_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 7 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char_T * blockType [ 7 ] = { "Scope" , "Scope" , "Scope" , "Scope" , "Scope"
, "S-Function" , "S-Function" , } ; static const char_T * blockPath [ 7 ] = {
"Proyecto/Scope" , "Proyecto/Subsitema MIC1/Fsonora" ,
"Proyecto/Subsitema MIC1/Posici&#xF3;n" ,
"Proyecto/Subsitema MIC1/Tensi&#xF3;n" ,
"Proyecto/Subsitema MIC1/Subsistema mec&#xE1;nico de membrana/Scope1" ,
"Proyecto/From Multimedia File" , "Proyecto/From Multimedia File1" , } ;
static const int reason [ 7 ] = { 0 , 0 , 0 , 0 , 0 , 1 , 1 , } ; for ( subs
[ 0 ] = 0 ; subs [ 0 ] < 7 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateString ( blockType [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 2 ; offset =
mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data , offset ,
mxCreateDoubleScalar ( ( real_T ) reason [ subs [ 0 ] ] ) ) ; } } return data
; } void MdlInitializeSizes ( void ) { ssSetNumContStates ( rtS , 2 ) ;
ssSetNumPeriodicContStates ( rtS , 0 ) ; ssSetNumY ( rtS , 0 ) ; ssSetNumU (
rtS , 0 ) ; ssSetDirectFeedThrough ( rtS , 0 ) ; ssSetNumSampleTimes ( rtS ,
2 ) ; ssSetNumBlocks ( rtS , 43 ) ; ssSetNumBlockIO ( rtS , 14 ) ;
ssSetNumBlockParams ( rtS , 8204 ) ; } void MdlInitializeSampleTimes ( void )
{ ssSetSampleTime ( rtS , 0 , 0.0 ) ; ssSetSampleTime ( rtS , 1 ,
0.09287981859410431 ) ; ssSetOffsetTime ( rtS , 0 , 0.0 ) ; ssSetOffsetTime (
rtS , 1 , 0.0 ) ; } void raccel_set_checksum ( ) { ssSetChecksumVal ( rtS , 0
, 4041121728U ) ; ssSetChecksumVal ( rtS , 1 , 1364811362U ) ;
ssSetChecksumVal ( rtS , 2 , 3135683545U ) ; ssSetChecksumVal ( rtS , 3 ,
867860109U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; static struct _ssBlkInfo2 blkInfo2 ;
static struct _ssBlkInfoSLSize blkInfoSLSize ; ( void ) memset ( ( char_T * )
rtS , 0 , sizeof ( SimStruct ) ) ; ( void ) memset ( ( char_T * ) & mdlInfo ,
0 , sizeof ( struct _ssMdlInfo ) ) ; ( void ) memset ( ( char_T * ) &
blkInfo2 , 0 , sizeof ( struct _ssBlkInfo2 ) ) ; ( void ) memset ( ( char_T *
) & blkInfoSLSize , 0 , sizeof ( struct _ssBlkInfoSLSize ) ) ;
ssSetBlkInfo2Ptr ( rtS , & blkInfo2 ) ; ssSetBlkInfoSLSizePtr ( rtS , &
blkInfoSLSize ) ; ssSetMdlInfoPtr ( rtS , & mdlInfo ) ; ssSetExecutionInfo (
rtS , executionInfo ) ; slsaAllocOPModelData ( rtS ) ; { static time_T
mdlPeriod [ NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ;
static time_T mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [
NSAMPLE_TIMES ] ; static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static
boolean_T mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T
mdlPerTaskSampleHits [ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T
mdlTimeOfNextSampleHit [ NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i <
NSAMPLE_TIMES ; i ++ ) { mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ;
mdlTaskTimes [ i ] = 0.0 ; mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } }
ssSetSampleTimePtr ( rtS , & mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , &
mdlOffset [ 0 ] ) ; ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ;
ssSetTPtr ( rtS , & mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , &
mdlSampleHits [ 0 ] ) ; ssSetTNextWasAdjustedPtr ( rtS , &
mdlTNextWasAdjustedPtr [ 0 ] ) ; ssSetPerTaskSampleHitsPtr ( rtS , &
mdlPerTaskSampleHits [ 0 ] ) ; ssSetTimeOfNextSampleHitPtr ( rtS , &
mdlTimeOfNextSampleHit [ 0 ] ) ; } ssSetSolverMode ( rtS ,
SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS , ( ( void * ) & rtB ) ) ;
( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof ( B ) ) ; } { real_T * x
= ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ; ( void ) memset ( ( void
* ) x , 0 , sizeof ( X ) ) ; } { void * dwork = ( void * ) & rtDW ;
ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork , 0 , sizeof ( DW )
) ; } { static DataTypeTransInfo dtInfo ; ( void ) memset ( ( char_T * ) &
dtInfo , 0 , sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS , & dtInfo ) ;
dtInfo . numDataTypes = 24 ; dtInfo . dataTypeSizes = & rtDataTypeSizes [ 0 ]
; dtInfo . dataTypeNames = & rtDataTypeNames [ 0 ] ; dtInfo . BTransTable = &
rtBTransTable ; dtInfo . PTransTable = & rtPTransTable ; dtInfo .
dataTypeInfoTable = rtDataTypeInfoTable ; } Proyecto_InitializeDataMapInfo (
) ; ssSetIsRapidAcceleratorActive ( rtS , true ) ; ssSetRootSS ( rtS , rtS )
; ssSetVersion ( rtS , SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS ,
"Proyecto" ) ; ssSetPath ( rtS , "Proyecto" ) ; ssSetTStart ( rtS , 0.0 ) ;
ssSetTFinal ( rtS , 5.0 ) ; { static RTWLogInfo rt_DataLoggingInfo ;
rt_DataLoggingInfo . loggingInterval = ( NULL ) ; ssSetRTWLogInfo ( rtS , &
rt_DataLoggingInfo ) ; } { { static int_T rt_LoggedStateWidths [ ] = { 1 , 1
} ; static int_T rt_LoggedStateNumDimensions [ ] = { 1 , 1 } ; static int_T
rt_LoggedStateDimensions [ ] = { 1 , 1 } ; static boolean_T
rt_LoggedStateIsVarDims [ ] = { 0 , 0 } ; static BuiltInDTypeId
rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE , SS_DOUBLE } ; static int_T
rt_LoggedStateComplexSignals [ ] = { 0 , 0 } ; static RTWPreprocessingFcnPtr
rt_LoggingStatePreprocessingFcnPtrs [ ] = { ( NULL ) , ( NULL ) } ; static
const char_T * rt_LoggedStateLabels [ ] = { "CSTATE" , "CSTATE" } ; static
const char_T * rt_LoggedStateBlockNames [ ] = {
"Proyecto/Subsitema MIC1/Subsistema mec&#xE1;nico de membrana/Integrator1" ,
"Proyecto/Subsitema MIC1/Subsistema mec&#xE1;nico de membrana/Integrator" } ;
static const char_T * rt_LoggedStateNames [ ] = { "" , "" } ; static
boolean_T rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 } ; static
RTWLogDataTypeConvert rt_RTWLogDataTypeConvert [ ] = { { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } } ; static int_T rt_LoggedStateIdxList [ ] = { 0 , 1 }
; static RTWLogSignalInfo rt_LoggedStateSignalInfo = { 2 ,
rt_LoggedStateWidths , rt_LoggedStateNumDimensions , rt_LoggedStateDimensions
, rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 2 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . elr4yukyrp ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtX . azsqxuyxrn ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"xFinal" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssJacobianPerturbationBounds jacobianPerturbationBounds ;
ssSetJacobianPerturbationBounds ( rtS , & jacobianPerturbationBounds ) ; } {
static ssSolverInfo slvrInfo ; static boolean_T contStatesDisabled [ 2 ] ;
static real_T absTol [ 2 ] = { 1.0E-6 , 1.0E-6 } ; static uint8_T
absTolControl [ 2 ] = { 0U , 0U } ; static real_T
contStateJacPerturbBoundMinVec [ 2 ] ; static real_T
contStateJacPerturbBoundMaxVec [ 2 ] ; static ssNonContDerivSigInfo
nonContDerivSigInfo [ 1 ] = { { 1 * sizeof ( real_T ) , ( char * ) ( & rtB .
nok05lpty1 ) , ( NULL ) } } ; { int i ; for ( i = 0 ; i < 2 ; ++ i ) {
contStateJacPerturbBoundMinVec [ i ] = 0 ; contStateJacPerturbBoundMaxVec [ i
] = rtGetInf ( ) ; } } ssSetSolverRelTol ( rtS , 0.001 ) ; ssSetStepSize (
rtS , 0.0 ) ; ssSetMinStepSize ( rtS , 0.0 ) ; ssSetMaxNumMinSteps ( rtS , -
1 ) ; ssSetMinStepViolatedError ( rtS , 0 ) ; ssSetMaxStepSize ( rtS ,
0.09287981859410431 ) ; ssSetSolverMaxOrder ( rtS , - 1 ) ;
ssSetSolverRefineFactor ( rtS , 1 ) ; ssSetOutputTimes ( rtS , ( NULL ) ) ;
ssSetNumOutputTimes ( rtS , 0 ) ; ssSetOutputTimesOnly ( rtS , 0 ) ;
ssSetOutputTimesIndex ( rtS , 0 ) ; ssSetZCCacheNeedsReset ( rtS , 0 ) ;
ssSetDerivCacheNeedsReset ( rtS , 0 ) ; ssSetNumNonContDerivSigInfos ( rtS ,
1 ) ; ssSetNonContDerivSigInfos ( rtS , nonContDerivSigInfo ) ;
ssSetSolverInfo ( rtS , & slvrInfo ) ; ssSetSolverName ( rtS , "ode45" ) ;
ssSetVariableStepSolver ( rtS , 1 ) ; ssSetSolverConsistencyChecking ( rtS ,
0 ) ; ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ;
ssSetSolverRobustResetMethod ( rtS , 0 ) ; ssSetAbsTolVector ( rtS , absTol )
; ssSetAbsTolControlVector ( rtS , absTolControl ) ;
ssSetSolverAbsTol_Obsolete ( rtS , absTol ) ;
ssSetSolverAbsTolControl_Obsolete ( rtS , absTolControl ) ;
ssSetJacobianPerturbationBoundsMinVec ( rtS , contStateJacPerturbBoundMinVec
) ; ssSetJacobianPerturbationBoundsMaxVec ( rtS ,
contStateJacPerturbBoundMaxVec ) ; ssSetSolverStateProjection ( rtS , 0 ) ;
ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetModelDerivatives ( rtS ,
MdlDerivatives ) ; ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ;
ssSetSolverShapePreserveControl ( rtS , 2 ) ; ssSetTNextTid ( rtS , INT_MIN )
; ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 0 ) ; ssSetContStateDisabled ( rtS ,
contStatesDisabled ) ; ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ; }
ssSetChecksumVal ( rtS , 0 , 4041121728U ) ; ssSetChecksumVal ( rtS , 1 ,
1364811362U ) ; ssSetChecksumVal ( rtS , 2 , 3135683545U ) ; ssSetChecksumVal
( rtS , 3 , 867860109U ) ; { static const sysRanDType rtAlwaysEnabled =
SUBSYS_RAN_BC_ENABLE ; static RTWExtModeInfo rt_ExtModeInfo ; static const
sysRanDType * systemRan [ 1 ] ; gblRTWExtModeInfo = & rt_ExtModeInfo ;
ssSetRTWExtModeInfo ( rtS , & rt_ExtModeInfo ) ;
rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo , systemRan ) ;
systemRan [ 0 ] = & rtAlwaysEnabled ; rteiSetModelMappingInfoPtr (
ssGetRTWExtModeInfo ( rtS ) , & ssGetModelMappingInfo ( rtS ) ) ;
rteiSetChecksumsPtr ( ssGetRTWExtModeInfo ( rtS ) , ssGetChecksums ( rtS ) )
; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS ) , ssGetTPtr ( rtS ) ) ; }
slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_Proyecto_GetSimStateDisallowedBlocks ) ; slsaGetWorkFcnForSimTargetOP (
rtS , mr_Proyecto_GetDWork ) ; slsaSetWorkFcnForSimTargetOP ( rtS ,
mr_Proyecto_SetDWork ) ; rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if (
ssGetErrorStatus ( rtS ) ) { return rtS ; } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 2 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID2 ( tid ) ; }
