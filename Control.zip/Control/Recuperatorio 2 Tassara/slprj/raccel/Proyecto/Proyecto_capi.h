#ifndef RTW_HEADER_Proyecto_capi_h_
#define RTW_HEADER_Proyecto_capi_h_
#include "Proyecto.h"
extern void Proyecto_InitializeDataMapInfo ( void ) ;
#endif
