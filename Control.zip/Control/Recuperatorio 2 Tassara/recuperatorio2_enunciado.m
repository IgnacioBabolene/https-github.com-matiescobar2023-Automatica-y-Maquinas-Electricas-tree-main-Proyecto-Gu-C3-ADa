%% Ejercicio 1. 
% Construya un modelo en simulink usando simscape (mec�nica 
% traslacional) de la suspensi�n de un cuarto de veh�culo (un colectivo).
% Los par�metros se dan abajo.
% Las perturbaciones del terreno aparecen a los 50 segundos y se modelan 
% como un ruido de 1 m/s^2 RMS (el bloque Band-Limited White Noise ya est� configurado)
% SI EL MODELO ES CORRECTO, generan compresiones de la suspensi�n 
% de 3 a 4 cm pico.
% (1 puntos)

%% Respuesta ejercicio 1
%   Para la resoluci�n de este ejercicio, se realiza un sistema
% simplificado el cual consiste en una masa que representa la rueda (m_u) con un
% resorte (k_u) y un amortiguador (c_u = 0 Ns/m) sujeta al suelo. Luego se
% coloca una segunda masa, que representa la masa del chasis (m_s), sujeta
% mediante un resorte (k_s) y un amortiguador a la rueda. Adem�s, se le
% agregan dos fuerzas entre las masas las cuales representan la subida y
% bajada de un pasajero (esta fuerza esta referenciada al suelo) y la
% accion del chofer (referenciada a la masa de la rueda, ya que esta fuerza no se
% transmite al suelo). Ademas se agrega un bloque de velocidad debajo de la
% rueda, el cual representa el movimiento del colectivo luego de arrancar.

%% Ejercicio 2. 
% Considerando un sensor ideal de distancia para medir la compresi�n de
% la suspensi�n:
% Implemente un PID para que el colectivo descienda y permita el ingreso 
% de pasajeros. 
% Este controlador, cuando el chofer da un escal�n a la referencia
% de -10 cm a los 10 s, debe hacer que la suspensi�n se comprima 10 cm, 
% sin error en estado estacionario, sin sobre-impulso y con un tiempo de 
% establecimiento de menos de 1.0 s.
% Por otra parte, cuando sube el pasajero, modelado como perturbaci�n
% tipo escal�n de 700 N a los 20 s, el controlador debe rechazar la 
% perturbaci�n con un tiempo de establecimiento de menos de 1.0 s.
% Un pasajero baja a los 25 s, lo cual tambi�n se modela con un escal�n.
% Para esto puede usar el comando 
% pidTuner(H, 'PID');
% y obtener las ganancias por tanteo observando la tabla mostrada al pulsar 
% el bot�n Show Parameters.
% (1 puntos)

%% Respuesta ejercicio 2
%   Gran parte de la resoluci�n se llev� a cabo en papel. All� se model� el
% sistema masa-resorte-amortiguador donde se hizo el diagrama de cuerpo
% libre con sus respectivas fuerzas. Luego se realiz� el sistema de
% ecuaciones correspondiente y se llevo a forma matricial, quedando asi de
% la siguiente forma:
%
%  x_dot = Ax+Bu
%  y = Cx
%
%   Una vez deducidas las matrices, se realiza la funci�n de tranferencia la
% cual me ayudar� a encontrar los K del PID a dise�ar. Para esto se utiliza
% la funci�n pidTuner y se modificaron los par�metros hasta tener las
% condiciones deseadas.
%
% Kp = 374837.2572
% Ki = 1166937.2604
% Kd = 30100.7976



%% Ejercicio 3
% Modifique el controlador de manera que la acci�n de control nunca 
% supere los 20000 N en valor absoluto. Se permite degradaci�n del
% desempe�o ante el escal�n en la referencia, pero ante el escal�n de la
% perturbaci�n debe mantener la din�mica.
% (1 puntos)

%% Respuesta Ejercicio 3
%   Para realizarlo, no se modificaron los valores de Kp, Ki, Kd. Se realiz�
% otra modifici�n la cual el PID del ejercicio 2 pasa a ser un I-PD. Esto
% pudo realizar una disminuci�n del m�ximo valor en valor absoluto y
% cumpliendo ocn la consigna de no superar los 20000N.


%% Ejercicio 4
% Agregue al modelo de simulink los componentes necesarios para modelar los
% siguientes detalles:
% La compresi�n de la suspensi�n se mide con tres sensores de distancia que
% tienen los siguientes ruidos (no correlacionados):
% Sensor A: 10 mm RMS (el bloque Band-Limited White Noise ya est� configurado)
% Sensor B: 5 mm RMS (el bloque Band-Limited White Noise ya est� configurado)
% Sensor C: 5 mm RMS (el bloque Band-Limited White Noise ya est� configurado)
% (1 punto)

%% Respuesta ejercicio 4
%   Solamente se conect� la salida real a los sumadores. Esta se�al limpia se
% suma con un ruido gaussiano, el cual simula un sensor de la vida real, ya
% que estos no devuelven una medici�n exacta debido al ruido.


%% Ejercicio 5
% Dise�e e implemente un observador de estado (posiblemente como filtro de 
% Kalman) de manera de tener una estimaci�n de la altura del chasis con un
% ruido RMS menor a 5 mm.
% (4 puntos) Si lo dise�a por ubicaci�n de polos (usando place o aker)
% (6 puntos) Si lo dise�a como filtro de Kalman-Bucy de tiempo continuo 
% (usando lqr), puede llegar a un ruido de 3.5 mm RMS en la primer intento
% correcto

%% Respuesta ejercicio 5
% Este ejercicio se realiz� de las dos maneras las cuales se explicar�n a continuaci�n:
%
%           ~~~Resoluci�n mediantes ubicaci�n de polos~~~
%
% Esta resoluci�n no es la mejor para este caso, ya que se requiere de un
% proceso iterativo y el resultado final no llega a ser tan bueno como lo
% es aplicando filtros de Kalman.
%
%   Para la resoluci�n se tuvo que realizar el polinomio caracteristico
% deseado. Este polinomio tiene la siguiente forma:
%
%                   (s^2) + 2*zeta*omega*s + w^2 = 0
%
%   Para buscar los valores de zeta y omega del polinomio antes nombrado, se
% utiliz� la tabla que se encuentra en el libro Astrom y Murray, el cual
% relaciona el overshoot y el tiempo de establecimiento con el omega y el
% zeta que deber�a tener el sistema. Una vez calculados (utilizando Mp = 0
% y Ts = 1), se procede a calcular los polos de dicho polinomio.
%   Sin embargo, es un polinomio de grado dos, y el polinomio caracteristico
% de la planta es de grado 4. Por esta raz�n se agregan 2 polos m�s, los
% cuales son lo suficientemente grandes como para que los polos dominantes
% sean los del polinomio caracteristico deseado.
%   Luego, para calcular la ganancia del observador, se utiliz� la funcion
% acker 3 veces (una para acda sensor), y luego se arm� un "L" el cual
% contemplara estas tres ganancias.
%   Finalmente, se realizaron las conexiones correspondientes en Simulink,
% utilizando un C_obs (matriz que contempla la salida  de los tres
% sensores), y B_ss_terreno (matriz de entrada el cual contempla
% aceleraciones producidas a las masas). Estas aceleraciones tendr�n los
% mismos sentidos para las dos masas, ya que es la ejercida por el
% terreno.
%
%               ~~~Resoluci�n mediantes filtro de Kalman~~~
%
%   Primero se realizaron, como se explic� anteriormente, las matrices
% C_obs y B_ss_terreno.
% Luego se realizaron las matrices Q_proceso y R_sensores, los cuales
% representan las perturbaciones y los ruidos de los sensores
% respectivamente. Sin embargo, hay que tener en cuenta, que los valores
% introducidos a estas matrices son de se�ales estoc�sticas. Esto quiere
% decir que no se pueden determinar con exactitud. Por ejemplo, no
% sabemos como ser� la condici�n de la ruta con exactidud en cada instante, pero si
% podriamos saber por donde circula el colectivo y teniendo la
% informacion suficiente de dicho camino, utilizar la raiz cuadr�tica
% media y utilizar ese valor (q) para relizar el filtro de Kalman. Esta
% misma explicaci�n se proyecta a los sensores, los cuales el ruido
% generado es de manera estoc�stica pero si podriamos tener la
% informacion de sus RMS.
%   Estos valores se introducen a las matrices Q_proceso (calculado como 
% B_ss_terreno * [q^2] * B_ss_terreno') y R_sensores (matriz diagonal)
% luego, utilizando la funci�n "lqr" se calcula la ganancia del observador.
%
% Conclusi�n: Se puede observar que utilizando 3 sensores, se puede lograr
% una mejor observaci�n de la posici�n.

%% Parameters (golden car)
clc
clear
close all

m_s = 3000;  % Sprung mass (masa del chasis por rueda) (kg)
k_s = 63.3*m_s;  % Spring stiffness (rigidez del resorte) (N/m)
c_s = 6*m_s;  % Damping coefficient (coeficiente de amortiguamiento del amortiguador) (Ns/m)
k_t = 653*m_s;  % Tire stiffness (rigidez del neum�tico) (N/m)
c_t = 0;  % Tire damping (Ns/m)
m_u = 0.15*m_s;  % (masa de la rueda) Unsprung mass (kg)


%% Dise�o del PID
% x = [pos_u
%      pos_s
%      vel_u
%      vel_s]

M = [m_u 0
     0   m_s];
K = [k_s+k_t -k_s
     -k_s     k_s]
C = [c_s+c_t -c_s
     -c_s     c_s]
A_ss = [ 0 0 1 0 
         0 0 0 1
        -M\K -M\C] 

B_ss = [ 0
         0
         (M^-1) * [ 1
                    -1 ]]

C_ss = [ -1 1 0 0]
D_ss = [ 0 ]
     
H = tf(ss(A_ss, B_ss, C_ss, D_ss))
stepinfo(H)
%pidTuner(H, 'PID');


%% Dise�o del filtro de Kalman
C_obs = [ 1 -1 0 0
          1 -1 0 0 
          1 -1 0 0 ]
B_ss_terreno = [ 0
                 0
                 -1
                 -1 ]
q = 0.8653;
Q_proceso = B_ss_terreno * [q^2] * B_ss_terreno';
r = [0.001;0.0005;0.0005];
R_sensores = [ r(1)^2 0       0 
               0       r(2)^2 0
               0       0       r(3)^2 ];

L = (lqr(A_ss', C_obs', Q_proceso, R_sensores))';

%% Dise�o por ubicaci�n de polos
Mp = 0;
Ts = 1;
zeta = sqrt(1/(pi^2/(log(Mp)^2)+1));
omega = 4/(zeta*Ts);
polos_deseados = (roots([1 2*zeta*omega omega^2]))';
polos_agregar = [polos_deseados(1)*3,polos_deseados(2)*3];
polos = [polos_deseados,polos_agregar];

rap = 4.5; %Representa la rapidez del observador con respecto a la planta
L1 = acker(A_ss',C_obs(1,:)',polos*rap)';
L2 = acker(A_ss',C_obs(2,:)',polos*rap)';
L3 = acker(A_ss',C_obs(3,:)',polos*rap)';
L = [L1,L2,L3];    %Descomentar si es que se quiere utilizar el m�todo por ubicaci�n de polos
